﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Demo1_Leica_Software_Engineering_Evaluation
{

    public partial class Form1 : Form
    {
        int rnd1 = 0; //initialize variable for random number 1
        int rnd2 = 0; //initialize variable for random number 1
        int tempo = 0; // temporary varaible for score
     
        System.Timers.Timer timer;
        int m = 1, tempoS = 59, s = 0;
        
        public Form1()
        {
            InitializeComponent();


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer = new System.Timers.Timer();
            timer.Interval = 1000; //ms
            timer.Elapsed += Timer_Elapsed;   //F. add timer 
           // timer.Start();
        }

        private void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            // throw new NotImplementedException();
            Invoke(new Action(() =>
            {
                
                m = m - 1;
                s = tempoS;
                if (m < 0)
                {
                    m = 0;
                    tempoS = tempoS - 1;
                    s = tempoS;
                }


                if (tempoS == 0) 
                {
                    //tempoS = 0;
                    s = tempoS;
                    time.Text = string.Format("{0}:{1}", m.ToString().PadLeft(2, '0'), s.ToString().PadLeft(2, '0')); //placed here to set timer to zero
                    timer.Stop();

                    if (MessageBox.Show("Time is up!! ", "Your Final Score is " + Score.Text, MessageBoxButtons.RetryCancel, MessageBoxIcon.Question) == DialogResult.Retry)
                    {    
                        m = 1; //reset minute
                        tempo = 0; //reset score 
                        tempoS = 59; //reset seconds
                        Score.Text = tempo.ToString(); // reset score on score board
                    }
                    else
                    {
                        Application.Exit(); // exits application
                    }
                }

                time.Text = string.Format("{0}:{1}", m.ToString().PadLeft(2, '0'), s.ToString().PadLeft(2, '0')); //updates the textbox timer for every interval.
            }

            ));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer.Start(); // start the timer once you start clicking 'button1'.
            generate(); // A. generate 2 random numbers
        }


        private void add_Click(object sender, EventArgs e)
        {

            int ans = Convert.ToInt32(Answer.Text);  // B. allows user to input number
            int result = rnd1 + rnd2; // adds up the 2 random number
            int scr = 0;

            if (ans == result)
            {
                scr = tempo + 1;
                tempo = scr; //E. keep score, temporary variable
                generate();  // D. call function to automatically generate new set of random numbers after start 
                MessageBox.Show("Correct answer keep going!", "GOOD JOB!!!", MessageBoxButtons.OK); // C. indicate wether user is correct
            }

            else
            {
                MessageBox.Show("Wrong answer try again", "Oooops!!!", MessageBoxButtons.OK); // C. indicate wether user is wrong
                scr = tempo - 1;
                tempo = scr; // E. keep score, temporary variable

                if (scr < 0) // score will not go down below zero 
                {
                    scr = 0; 
                    tempo = 0;
                }
                
            }

            Score.Text = scr.ToString(); // show score to textbox
        }


        // private void Add()
        private void generate()
        {
            //  int[] arr = new int[2];
            //  int rnd1 = 0;
            //  int rnd2 = 0;
            Random Random = new Random();

            for (int i = 0; i < 2; i++)
            {
                rnd1 = Random.Next(0, 101);                  //random number from 0 up to 100 only
                //  while (!(arr.Contains(rnd1)))
                //     {
                //         arr[i] = rnd1;
                //     }

                textBox1.Text = rnd1.ToString(); //show value on textbox
            }

            for (int i = 0; i < 2; i++)                     
            {
                rnd2 = Random.Next(0, 101);                 //random number from 0 up to 100 only
                // while (!(arr.Contains(rnd2)))
                // {
                //     arr[i] = rnd2;
                // }

                textBox2.Text = rnd2.ToString(); //show value on textbox       
            }

            // Random Random1 = new Random();
            //  Random Random2 = new Random();
            //  int rnd1 = Random1.Next(0, 101);
            //  int rnd2 = Random2.Next(0, 101);

            // textBox1.Text = rnd1.ToString();
            // textBox2.Text = rnd2.ToString();

        }




        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

    }

}
