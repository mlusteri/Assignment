﻿namespace Demo1_Leica_Software_Engineering_Evaluation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.First_number = new System.Windows.Forms.Label();
            this.Second_number = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Answer = new System.Windows.Forms.TextBox();
            this.SUM = new System.Windows.Forms.Label();
            this.TIMER = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Score = new System.Windows.Forms.TextBox();
            this.scr = new System.Windows.Forms.Label();
            this.add = new System.Windows.Forms.Button();
            this.time = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // First_number
            // 
            this.First_number.AutoSize = true;
            this.First_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.First_number.Location = new System.Drawing.Point(92, 111);
            this.First_number.Name = "First_number";
            this.First_number.Size = new System.Drawing.Size(122, 25);
            this.First_number.TabIndex = 0;
            this.First_number.Text = "1st Number";
            this.First_number.Click += new System.EventHandler(this.label1_Click);
            // 
            // Second_number
            // 
            this.Second_number.AutoSize = true;
            this.Second_number.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Second_number.Location = new System.Drawing.Point(92, 163);
            this.Second_number.Name = "Second_number";
            this.Second_number.Size = new System.Drawing.Size(129, 25);
            this.Second_number.TabIndex = 1;
            this.Second_number.Text = "2nd Number";
            this.Second_number.Click += new System.EventHandler(this.label2_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(270, 117);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(116, 31);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(268, 160);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(116, 31);
            this.textBox2.TabIndex = 3;
            // 
            // Answer
            // 
            this.Answer.BackColor = System.Drawing.SystemColors.Window;
            this.Answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Answer.Location = new System.Drawing.Point(268, 257);
            this.Answer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Answer.Name = "Answer";
            this.Answer.Size = new System.Drawing.Size(118, 31);
            this.Answer.TabIndex = 4;
            this.Answer.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // SUM
            // 
            this.SUM.AutoSize = true;
            this.SUM.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SUM.Location = new System.Drawing.Point(94, 257);
            this.SUM.Name = "SUM";
            this.SUM.Size = new System.Drawing.Size(127, 25);
            this.SUM.TabIndex = 5;
            this.SUM.Text = "INPUT SUM";
            this.SUM.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // TIMER
            // 
            this.TIMER.AutoSize = true;
            this.TIMER.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TIMER.Location = new System.Drawing.Point(468, 41);
            this.TIMER.Name = "TIMER";
            this.TIMER.Size = new System.Drawing.Size(77, 30);
            this.TIMER.TabIndex = 6;
            this.TIMER.Text = "TIMER";
            this.TIMER.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(499, 142);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(172, 146);
            this.button1.TabIndex = 7;
            this.button1.Text = "GENERATE RANDOM NUMBERS TO START";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Score
            // 
            this.Score.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Score.Location = new System.Drawing.Point(570, 363);
            this.Score.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(116, 31);
            this.Score.TabIndex = 8;
            this.Score.TextChanged += new System.EventHandler(this.textBox3_TextChanged_1);
            // 
            // scr
            // 
            this.scr.AutoSize = true;
            this.scr.BackColor = System.Drawing.Color.Red;
            this.scr.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scr.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.scr.Location = new System.Drawing.Point(585, 334);
            this.scr.Name = "scr";
            this.scr.Size = new System.Drawing.Size(86, 25);
            this.scr.TabIndex = 9;
            this.scr.Text = "SCORE";
            this.scr.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add.ForeColor = System.Drawing.Color.Navy;
            this.add.Location = new System.Drawing.Point(248, 334);
            this.add.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(160, 74);
            this.add.TabIndex = 10;
            this.add.Text = "SUBMIT ANSWER";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // time
            // 
            this.time.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.time.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time.Location = new System.Drawing.Point(542, 42);
            this.time.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(116, 31);
            this.time.TabIndex = 11;
            this.time.TextChanged += new System.EventHandler(this.textBox3_TextChanged_2);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(732, 594);
            this.Controls.Add(this.time);
            this.Controls.Add(this.add);
            this.Controls.Add(this.scr);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.TIMER);
            this.Controls.Add(this.SUM);
            this.Controls.Add(this.Answer);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Second_number);
            this.Controls.Add(this.First_number);
            this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "RANDOM NUMBER ADDITON TEST";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Second_number;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox Answer;
        private System.Windows.Forms.Label SUM;
        private System.Windows.Forms.Label TIMER;
        private System.Windows.Forms.Label First_number;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Score;
        private System.Windows.Forms.Label scr;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.TextBox time;
    }
}

